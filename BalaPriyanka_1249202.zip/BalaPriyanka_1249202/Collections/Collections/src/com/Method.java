package com;

import java.util.HashMap;

public class Method {
	public void getMethod(){
		int k=0;
		HashMap<Integer, MyCollection> hm=new HashMap<>();
		if(hm.containsKey(k)){
			System.out.println("the elements is present");
		}
		else
	System.out.println("not present");
	}

}
