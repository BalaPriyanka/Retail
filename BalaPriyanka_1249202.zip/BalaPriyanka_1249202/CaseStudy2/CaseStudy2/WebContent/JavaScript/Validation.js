
function userid()
{
	
	var Id= document.myform.id.value;
	if(Id=="")
		{
		alert("Enter the Name");
		return false;
		}
	else if(Id.length<8)
		{
		alert("Number should be btween 8 to 12");
		return false;
		}
	else
		{
		return true;
		}
	
		
		
	
}
function validateFirstName() 
{
		var letters = /^[A-Za-z]+$/;
        var x = document.myform.fname.value;
        if (x == null || x == "") {
            alert("First name cannot be left blank.");
            return false;
        }
        else if(x!=letters){
        	  
        	
        	alert('Name must contain Characters only!!!');  
        	  
        	return false;  
        	}
        else
        	
            {
                return true;
            }
        }

function pswd()

{ 
	var ps=document.myform.pwd.value;
	
	if(ps=="")
		{
		alert("Enter the password");
		return false;
			
		}
	
	else
		{
		return true;
		}
}
function conformpswd()
{
	var ps=document.myform.pwd.value;
	var cnp=document.myform.cp.value;
	if(cnp!=ps)
		{
		alert("Password and Conform Password not match");
		return false;
		}
	else
		{
		return true;
		}
}

/*function age()
{
	var ps=document.myform.first.value;
	
	if(ps=="")
	{
	alert("Enter the Age");
	return false;
		
	}
}*/
function Email()
{
	var ps=document.myform.emailid.value;
	if (ps="")
	  {
		alert("Enter Email ID!");
	    return (false);
	  }
	else 
		{
		return true;
		}
	
}
function PhNum()
{
	var ps=document.myform.mobile.value;
	if(ps=="")
	{
	alert("Enter the Phone Number");
	return false;
	}
else if(ps.length<10)
	{
	alert("Number should be 10 digit");
	return false;
	}
else
	{
	return true;
	}
	
}


