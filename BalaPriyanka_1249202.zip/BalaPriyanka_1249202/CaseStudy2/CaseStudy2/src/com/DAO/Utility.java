package com.DAO;

import java.sql.*;

public class Utility {

	private  static final String URL = "jdbc:oracle:thin:@inchnilpdb03.India.TCS.com:1521:JavaDB03";
	private static final String DRIVERNAME = "oracle.jdbc.OracleDriver";
	private static final String USERNAME = "E1206715";
	private static final String PASSWORD = "E1206715";

	public static void closeConnection(Connection con) {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static void closeStatement(PreparedStatement pstmt) {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(DRIVERNAME);
			con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			System.out.println("CONN"+con);

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
}
