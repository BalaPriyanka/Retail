package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pojo.Registration;

public class DAOOperations {

	private static Connection conn = null;

	public static int addRegistration(Registration e)
	{
		int curId=0,n=0;
		if (e != null)
		{
			try
			{
				System.out.println(e.toString());

				conn = Utility.getConnection();	
				String query = "insert into irctc values(?,?,?,?,?,?,?,?,?,?,?)";

				PreparedStatement pstmt1 = conn.prepareStatement(query);
				pstmt1.setString(1,e.getUserid());
				pstmt1.setString(2,e.getPassword());
				pstmt1.setString(3,e.getConfirmPassword());
				pstmt1.setString(4,e.getLang());
				pstmt1.setString(5,e.getFirstName());
				pstmt1.setString(6,e.getLastName());
				pstmt1.setString(7,e.getGender());
				pstmt1.setString(8,e.getMaritalStatus());
				pstmt1.setDate(9,e.getDOB());
				pstmt1.setString(10,e.getEmailid());
				pstmt1.setLong(11,e.getMobile());



				n=pstmt1.executeUpdate();
			} 
			catch (SQLException ee)
			{
				// TODO Auto-generated catch block
				ee.printStackTrace();
			} 
			finally
			{

				Utility.closeConnection(conn);

			}
		}
		return n;
		
	}


	public static int login(String id,String pwd)
	{
		String s=null;
		int flag=-1;
		try
		{	

			conn = Utility.getConnection();
			String query = "select userid from irctc where userid=? and pwd=?";
			PreparedStatement pstmt1 = conn.prepareStatement(query);
			pstmt1.setString(1,id);
			pstmt1.setString(2,pwd);

			ResultSet rs = pstmt1.executeQuery();
			while(rs.next())
				s = rs.getString(1);
				
			System.out.println("s="+s);
			System.out.println("id="+id);

			if(s.equals(id))
			{
				flag = 1;
				System.out.println(flag);

			}
			else
			{
				flag=-1;

			}


		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		finally
		{

			Utility.closeConnection(conn);

		}
		return flag;
	}

}
